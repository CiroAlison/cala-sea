/* ═══════════════════════════════════════════
   CALA SEA – script.js
   ═══════════════════════════════════════════ */

/* ─── Navbar scroll ─── */
const navbar = document.getElementById('navbar');
const floatCta = document.getElementById('floatCta');
let lastY = 0;

window.addEventListener('scroll', () => {
  const y = window.scrollY;
  navbar.classList.toggle('scrolled', y > 60);
  /* Show floating CTA after scrolling past hero */
  if (floatCta) floatCta.classList.toggle('show', y > window.innerHeight * 0.6);
  lastY = y;
}, { passive: true });

/* ─── Burger / mobile nav ─── */
const burger   = document.getElementById('burger');
const navLinks = document.getElementById('navLinks');
const overlay  = document.getElementById('navOverlay');

function openMenu()  { burger.classList.add('open'); navLinks.classList.add('open'); overlay.classList.add('show'); document.body.style.overflow = 'hidden'; }
function closeMenu() { burger.classList.remove('open'); navLinks.classList.remove('open'); overlay.classList.remove('show'); document.body.style.overflow = ''; }

burger.addEventListener('click', () => navLinks.classList.contains('open') ? closeMenu() : openMenu());
window.closeMenu = closeMenu; // exposed to inline onclick

/* ─── Scroll fade-in ─── */
const io = new IntersectionObserver((entries) => {
  entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('visible'); io.unobserve(e.target); } });
}, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });
document.querySelectorAll('.fade-in').forEach(el => io.observe(el));

/* ─── Menu tabs ─── */
document.querySelectorAll('.tab-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
    btn.classList.add('active');
    const t = document.getElementById('tab-' + btn.dataset.tab);
    if (t) t.classList.add('active');
  });
});

/* ─── Booking form ─── */
const form = document.getElementById('booking-form');
if (form) {
  /* Min date = today */
  const dateInput = document.getElementById('data');
  if (dateInput) dateInput.min = new Date().toISOString().split('T')[0];

  form.addEventListener('submit', e => {
    e.preventDefault();
    let valid = true;
    form.querySelectorAll('[required]').forEach(f => {
      f.classList.remove('error');
      const bad = f.type === 'checkbox' ? !f.checked : !f.value.trim();
      if (bad) { f.classList.add('error'); valid = false; }
    });
    if (!valid) { form.querySelector('.error')?.scrollIntoView({ behavior: 'smooth', block: 'center' }); return; }

    const nome    = document.getElementById('nome').value.trim();
    const data    = document.getElementById('data').value;
    const persone = document.getElementById('persone').value;
    const tipo    = document.getElementById('tipo').value;
    const dateStr = data ? new Date(data + 'T00:00:00').toLocaleDateString('it-IT', { weekday:'long', day:'numeric', month:'long', year:'numeric' }) : '';

    window.location.href = 'grazie.html?' + new URLSearchParams({ nome, data: dateStr, persone, tipo });
  });
}

/* ─── Smooth scroll ─── */
document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener('click', e => {
    const id = a.getAttribute('href').slice(1);
    const el = document.getElementById(id);
    if (el) { e.preventDefault(); el.scrollIntoView({ behavior: 'smooth' }); }
  });
});
